﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public enum EnumRolId
    {
       ModificarPersona = 1,
       AutorizarModificarPersona = 2,
       DesbloquearCredencial = 3,
       AutorizarDesbloquearCredencial = 4,
       Operador = 5
    }
}
