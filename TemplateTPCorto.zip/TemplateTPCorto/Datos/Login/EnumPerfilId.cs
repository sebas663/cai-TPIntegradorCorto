﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public enum EnumPerfilId
    {
        Operador = 1,
        Supervisor = 2,
        Administrador = 3
    }
}
